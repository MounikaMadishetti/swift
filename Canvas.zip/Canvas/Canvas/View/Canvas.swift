//
//  Canvas.swift
//  Canvas
//
//  Created by Mounika Madishetti on 23/02/21.
//  Copyright © 2021 Mounika Madishetti. All rights reserved.
//

import UIKit

class Canvas: UIView {
    
    override func draw(_ rect: CGRect) {
        super.draw(rect)
        guard let context = UIGraphicsGetCurrentContext() else {return}

      lines.forEach({(line) in
            context.setStrokeColor(line.color)
            context.setLineWidth(CGFloat(line.strokeWidth))
            context.setLineCap(.round)
        context.setFlatness(CGFloat(2))
            if(line.isDottedLine) {
            context.setLineDash(phase: 4, lengths: [CGFloat(10)])
            }
            else {
                context.setLineDash(phase: 0, lengths: [])
        }
            for(index, point) in line.points.enumerated() {
                if(index == 0){
                    context.move(to: point)
                } else {
                    context.addLine(to: point)
                    
                }
            }
            context.strokePath()
        
      })
        
    }
    var dottedLine = false 
    var lines = [Line]()
    var strokeColor = UIColor.black.cgColor
    var strokeWidth: CGFloat = 1
    var linesCount = 0
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        lines.append(Line.init(strokeWidth: Float(strokeWidth), color: strokeColor, points: [], isDottedLine: self.dottedLine))
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let point = touches.first?.location(in: nil) else {return}
        guard var lastLine = lines.popLast() else {return}
        lastLine.points.append(point)
        lines.append(lastLine)
        setNeedsDisplay()
    }
    func undo() {
        _ = lines.popLast()
        setNeedsDisplay()
    }
    func clear() {
        lines.removeAll()
        setNeedsDisplay()
    }
    func changeColor(color: UIColor) {
        self.strokeColor = color.cgColor
    }
    func changeWidth(width: CGFloat) {
        self.strokeWidth = width
    }
    func changeDottedLine(dottedLine: Bool){
        self.dottedLine = dottedLine
    }
    
}
