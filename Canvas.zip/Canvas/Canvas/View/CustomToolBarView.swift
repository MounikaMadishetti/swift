//
//  CustomToolBarView.swift
//  Canvas
//
//  Created by Mounika Madishetti on 25/02/21.
//  Copyright © 2021 Mounika Madishetti. All rights reserved.
//

import UIKit

class CustomToolBarView: UIView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
