//
//  Line.swift
//  Canvas
//
//  Created by Mounika Madishetti on 23/02/21.
//  Copyright © 2021 Mounika Madishetti. All rights reserved.
//

import UIKit
struct Line {
    let strokeWidth: Float
    let color: CGColor
    var points: [CGPoint]
    var isDottedLine: Bool 
}

