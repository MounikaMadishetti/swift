//
//  ViewController.swift
//  Canvas
//
//  Created by Mounika Madishetti on 23/02/21.
//  Copyright © 2021 Mounika Madishetti. All rights reserved.
//

import UIKit
import Foundation

class ViewController: UIViewController {
    
    let undoButton: UIButton = {
        let btn = UIButton(type: .system)
        btn.setTitle("Undo", for: .normal)
        btn.titleLabel?.font = .boldSystemFont(ofSize: 14)
        btn.addTarget(self, action: #selector(handleUndo), for: .touchUpInside)
        return btn
    }()
    let clearButton: UIButton = {
        let btn = UIButton(type: .system)
        btn.setTitle("Clear", for: .normal)
        btn.titleLabel?.font = .boldSystemFont(ofSize: 14)
        btn.addTarget(self, action: #selector(handleClear), for: .touchUpInside)
        return btn
    }()
    let yellowButton: UIButton = {
        let btn = UIButton(type: .system)
        btn.backgroundColor = .yellow
        btn.layer.borderWidth = 1
        btn.addTarget(self, action: #selector(changeColor), for: .touchUpInside)
        return btn
    }()
    let redButton: UIButton = {
        let btn = UIButton(type: .system)
        btn.backgroundColor = .red
        btn.layer.borderWidth = 1
        btn.addTarget(self, action: #selector(changeColor), for: .touchUpInside)
        return btn
    }()
    let blueButton: UIButton = {
        let btn = UIButton(type: .system)
        btn.backgroundColor = .blue
        btn.layer.borderWidth = 1
        btn.addTarget(self, action: #selector(changeColor), for: .touchUpInside)
        return btn
    }()
    let slider: UISlider = {
        let slider = UISlider()
        slider.minimumValue = 1
        slider.maximumValue = 10
        slider.addTarget(self, action: #selector(changeWidth), for: .valueChanged)
        return slider
    }()
    let dottedLine: UIButton = {
           let btn = UIButton(type: .system)
        
           btn.setTitle("Dotted", for: .normal)
           btn.titleLabel?.font = .boldSystemFont(ofSize: 14)
        btn.addTarget(self, action: #selector(changeLineType(_: )), for: .touchUpInside)
           return btn
       }()
    let straightLine: UIButton = {
        let btn = UIButton(type: .system)
     
        btn.setTitle("straight Line", for: .normal)
        btn.titleLabel?.font = .boldSystemFont(ofSize: 14)
        btn.addTarget(self, action: #selector(changeLineType(_: )), for: .touchUpInside)
        return btn
    }()
    let canvas = Canvas()
    override func loadView() {
        self.view = canvas
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        canvas.backgroundColor = .white
        let colorsStackView = UIStackView(arrangedSubviews:[yellowButton, blueButton, redButton])
        colorsStackView.distribution = .fillEqually
        let stackView = UIStackView(arrangedSubviews: [undoButton, straightLine, dottedLine,clearButton, colorsStackView, slider])
        stackView.spacing = 2
        stackView.distribution = .fillEqually
        view.addSubview(stackView)
        stackView.translatesAutoresizingMaskIntoConstraints = false
        stackView.leadingAnchor.constraint(equalTo: view.leadingAnchor).isActive = true
        stackView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor).isActive = true
        stackView.trailingAnchor.constraint(equalTo: view.trailingAnchor).isActive = true
    }
    @objc func handleUndo() {
        canvas.undo()
    }
    @objc func handleClear() {
        canvas.clear()
    }
    @objc func changeColor(button: UIButton) {
        canvas.changeColor(color: button.backgroundColor ?? .black)
    }
    @objc func changeWidth() {
        canvas.changeWidth(width: CGFloat(slider.value))
    }
    @objc func changeLineType(_ sender: UIButton) {
        if(sender.titleLabel?.text == "Dotted") {
        canvas.changeDottedLine(dottedLine: true)
    } else {
    canvas.changeDottedLine(dottedLine: false)
    }
    }
}

